# GitHub Pages — готовая демо-версия

В корне находится `index.html`.

## Как загрузить

1. Откройте нужный репозиторий GitHub.
2. Загрузите файл `index.html` именно в корень репозитория.
3. Откройте Settings → Pages.
4. Source: Deploy from a branch.
5. Branch: main.
6. Folder: / (root).
7. Save.

После публикации GitHub Pages должен открыть `index.html` автоматически.

Важно: не загружайте папку `github_ready_product_assistant` целиком как вложенную папку.
Нужно загрузить именно её содержимое, чтобы `index.html` лежал в корне репозитория.
